


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_JARVISGUI(object):
    def setupUi(self, JARVISGUI):
        JARVISGUI.setObjectName("JARVISGUI")
        JARVISGUI.resize(1004, 739)
        font = QtGui.QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        font.setStrikeOut(True)
        JARVISGUI.setFont(font)
        JARVISGUI.setWindowOpacity(6.0)
        JARVISGUI.setToolTipDuration(12)
        self.centralwidget = QtWidgets.QWidget(JARVISGUI)
        self.centralwidget.setObjectName("centralwidget")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(740, 610, 101, 51))
        font = QtGui.QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        font.setStrikeOut(False)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);")
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(860, 610, 101, 51))
        font = QtGui.QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        font.setStrikeOut(False)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setAutoFillBackground(False)
        self.pushButton_2.setStyleSheet("color: rgb(255, 255, 255);\n"
"background-color: rgb(66, 66, 198);")
        self.pushButton_2.setObjectName("pushButton_2")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(10, 10, 401, 101))
        self.label_2.setText("")
        self.label_2.setPixmap(QtGui.QPixmap("E:/gifs for jarvis/T8bahf.gif"))
        self.label_2.setObjectName("label_2")
        self.textBrowser = QtWidgets.QTextBrowser(self.centralwidget)
        self.textBrowser.setGeometry(QtCore.QRect(440, 30, 256, 41))
        font = QtGui.QFont()
        font.setStrikeOut(False)
        self.textBrowser.setFont(font)
        self.textBrowser.setStyleSheet("background:trandsparent;\n"
"border-radius:none;\n"
"color:white;\n"
"font-size:20px;"
)
        self.textBrowser.setObjectName("textBrowser")
        self.textBrowser_2 = QtWidgets.QTextBrowser(self.centralwidget)
        self.textBrowser_2.setGeometry(QtCore.QRect(730, 30, 256, 41))
        font = QtGui.QFont()
        font.setStrikeOut(False)
        self.textBrowser_2.setFont(font)
        self.textBrowser_2.setStyleSheet("background:trandsparent;\n"
"border-radius:none;\n"
"color:white;\n"
"font-size:20px;"
)
        self.textBrowser_2.setObjectName("textBrowser_2")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(770, 220, 231, 221))
        self.label_5.setText("")
        self.label_5.setPixmap(QtGui.QPixmap("D:/download/jaa.gif"))
        self.label_5.setScaledContents(False)
        self.label_5.setObjectName("label_5")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(0, -5, 1021, 731))
        self.label.setStyleSheet("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);")
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("D:/download/960x0.jpg"))
        self.label.setScaledContents(True)
        self.label.setObjectName("label")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(10, 600, 671, 91))
        self.label_3.setText("")
        self.label_3.setPixmap(QtGui.QPixmap("D:/download/loading.gif"))
        self.label_3.setObjectName("label_3")
        self.label.raise_()
        self.label_5.raise_()
        self.pushButton.raise_()
        self.pushButton_2.raise_()
        self.label_2.raise_()
        self.textBrowser.raise_()
        self.textBrowser_2.raise_()
        self.label_3.raise_()   
        JARVISGUI.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(JARVISGUI)
        self.statusbar.setObjectName("statusbar")
        JARVISGUI.setStatusBar(self.statusbar)

        self.retranslateUi(JARVISGUI)
        QtCore.QMetaObject.connectSlotsByName(JARVISGUI)

    def retranslateUi(self, JARVISGUI):
        _translate = QtCore.QCoreApplication.translate
        JARVISGUI.setWindowTitle(_translate("JARVISGUI", "MainWindow"))
        self.pushButton.setText(_translate("JARVISGUI", "START"))
        self.pushButton_2.setText(_translate("JARVISGUI", "EXIT"))
        self.textBrowser_2.setHtml(_translate("JARVISGUI", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'Times New Roman\'; font-size:10pt; font-weight:600; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    JARVISGUI = QtWidgets.QMainWindow()
    ui = Ui_JARVISGUI()
    ui.setupUi(JARVISGUI)
    JARVISGUI.show()
    sys.exit(app.exec_())

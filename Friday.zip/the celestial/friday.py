from ast import operator
from cgitb import text
import sys
from time import time
from tracemalloc import start
from winreg import HKEY_LOCAL_MACHINE
from pip import main
import pyttsx3 
import datetime
import wikipedia 
import webbrowser
import os
from googletrans import Translator
import speech_recognition as sq 
from PyQt5 import QtWidgets,QtCore,QtGui
from PyQt5.QtCore import QTimer,QTime,QDate,Qt
from PyQt5.QtGui import QMovie
from PyQt5.QtCore import*
from PyQt5.QtGui import*
from PyQt5.QtWidgets import*
from PyQt5.uic import loadUiType
from celestialgui import Ui_JARVISGUI
import requests
from bs4 import BeautifulSoup
import subprocess as sp
import pyautogui
from time import sleep
import time
from notes import takecommand
from sys import exit
import cv2
import numpy as np
from PIL import Image 
import os
import pyautogui as p
import psutil
import pywikihow
from pywikihow import search_wikihow


engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')

engine.setProperty('voice',voices[1].id)
def speak(audio):
    engine.say(audio)
    engine.runAndWait()

     
class mainthread(QThread):
    def __init__(self):
        super(mainthread,self).__init__()
        
    def run (self):
        self.TaskExecution() 
        
        
          
    def takecommand(self): 
            r = sq.Recognizer()
            with sq.Microphone()as so:
                print("Listening.....")
                r.pause_threshold = 1
                audio = r.listen(so)
                
            try:
                print("Wait for few moments...")
                que = r.recognize_google(audio,language='en-in')
                print(f"YOU SAID : {que}")
            except Exception as w:
                print("SAY IT AGAIN PLEASE....")
                return "none"
            return que
        

        
    def wishme(self):
        h= int(datetime.datetime.now().hour)
        if h>=0 and h<12:
            speak("GOOD MORNING BOSS !")
            print("GOOD MORNING BOOS !")
        elif h>=12 and h>12:
            speak("GOOD AFTERNOON Boss!")
            print("GOOD AFTERNOON Boss!")
        else:
            speak("GOOD EVENING BOSS!")
            print("GOOD EVENING BOSS!")
            
            
        speak("INITIALISING ALL SERVICES ")
        speak("CHECKING PROCESSORS ") 
        speak("every thing working perfectly")
        speak("I AM ONLINE SIR")
        speak("I AM friday ,SPEED 100 TERABYTES ,PLEASE TELL HOW MAY I HELP YOU")
    
    
        
                
    def TaskExecution(self):
        speak("welcome back arjun sir")
        strtime = datetime.datetime.now().strftime("%H:%M:%S")
        speak(f"SIR ,the time is {strtime}")
        self.wishme()
        while True:
            self.que = self.takecommand().lower()
            if 'wikipedia' in self.que:
                speak('searching wikipedia...')  
                self.que = self.que.replace("wikipedia", "") 
                results = wikipedia.summary(self.que, sentences=2) 
                speak("According to wikipedia")  
                print(results)
                speak(results)
                
                
            elif 'open youtube' in self.que:
                speak("SURE SIR")
                webbrowser.open("youtube.com")
                
                
            elif'open google' in self.que:
                speak("SURE SIR")
                webbrowser.open("google.com")
                
                
            elif'open instagram' in self.que:
                speak("SURE SIR")
                webbrowser.open("instagram.com")
                
                
            elif'open twitter'in self.que:
                speak("SURE SIR")
                webbrowser.open("twitter.com")
                
                
            elif 'the time' in self.que:
                speak("SURE SIR")
                strtime = datetime.datetime.now().strftime("%H:%M:%S")
                speak(f"SIR ,the time is {strtime}")
                
                
            elif 'code' in self.que:
                speak("SURE SIR")
                path = "C:\\Users\\91987\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
                os.startfile(path)
            
                
            elif 'weather'in self.que:
                speak("SURE SIR")
                search = "weather in punjab"
                url = f"https://www.google.com/search?q={search}"
                r = requests.get(url)
                data = BeautifulSoup(r.text,"html.parser")
                temp = data.find("div",class_="BNeawe").text
                speak(f"current {search} is {temp}")
             
                
            elif 'what are you capable of' in self.que:
                
                speak("I AM YOUR SERVENT MY LORD,I CAN DO A SIMPLE TASKS FOR YOU LIKE OPENING DIFFERENT WEB APPLICATIONS AND TELLING YOU TIME , OPEN APPLICATIONS LIKE NOTEPAD ,CAN CALCULATE FOR YOU, TELL YOU ABOUT WEATHER AND TRANSLATE ANY THING FOR YOU I AM VERY SMART BUT STILL WORK IN PROGRESS MY CREATOR MKAES VERY SMART")
             
                
            elif 'thank you' in self.que:
                
                speak("IT'S MY PLEASURE SIR")
                
            elif 'hello' in self.que:
                speak("hello sir")
                speak("how are you sir")
                
            elif 'about you'in self.que:
                speak("i am fine sir , how can i help you")
                
            elif 'tell me a joke' in self.que:
                speak("if child labour is crime then why teachers give us homework   ha ha ha ha")
                
            elif 'riddle 'in self.que:
                speak("which animal can jump higher than tree")
                print('all animals can jump higher than tree because tree never jumps')
                
            elif 'who are siri and elexa'in self.que:
                speak("they are like childs in front of me.")
                
            elif'your creator'in self.que:
                speak("ARJUN SHARMA IS CREATOR OF MY BRAIN AND BHARAT AND HARSIMRAN DESIGNED MY INTERFACE")
                
            elif'are you smart' in self.que:
                speak("is there any doubt")
                
            elif 'best country in the world' in self.que:
                speak("hindustan zindabad tha , hai , or rhega")
             
                
            elif 'type for me' in self.que:
                speak("SURE SIR")
                from notes import Notepad
                Notepad()
              
                
            elif 'task manager' in self.que:
                speak("SURE SIR")
                p1 = "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\System Tools"
                os.startfile(p1)
              
                
                            
            elif "play video" in self.que:
                speak("SURE SIR")
                p2 = "D:\\vedios"
                vedios = os.listdir(p2)
                print(vedios)
                os.startfile(os.path.join(p2,vedios[0]))
            
            
            elif 'horoscope'in self.que:
                speak("SURE SIR")
                webbrowser.open("horoscope.com")
                
                
            elif'news'in self.que:
                speak("SURE SIR")
                webbrowser.open("timesofindia.com")
             
                
            elif "where i am" in self.que:
                
                
                speak("wait sir, let me check")
                try:
            
                    ipAdd = requests.get('https://api.ipify.org').text
                    url = 'https://get.geojs.io/v1/ip/geo/'+ipAdd+'.json'
                    geo_requests = requests.get(url)
                    geo_data = geo_requests.json()
                    city = geo_data['city']
                    region = geo_data['region']
                    country = geo_data['country']
                    speak(f"sir i am not sure , but i think we are in {city} city of {region} state in {country} country")
                except Exception as e:
                    speak("sorry sir , due to network issue i am unable to find where we are.")
            
            
            
            elif "take screenshot" in self.que:
                speak("SURE SIR")
                speak("sir,please tell me the name for this screenshot file")
                name = takecommand().lower()
                speak("please sir hold the screen for few seconds, i am taking screenshot")
                time.sleep(5)
                
                
                img = pyautogui.screenshot()
                img.save(f"{name}.png")
                speak("i am done sir , the screenshot is saved in our main folder, now i am ready for next task")
                
                
            elif "open linkedin" in self.que:
                speak("SURE SIR")
                webbrowser.open("linkedin.com")
                
            elif "how much battery left" in self.que or "battery" in self.que:
                battery = psutil.sensors_battery()
                percentage = battery.percent
                speak(f'sir our battery has{percentage}battery left')
                
                
            elif"activate how to do something"in self.que:
                speak("how to do mod is activated please tell what you want to know")
                how = takecommand()
                max = 1
                how_1 = search_wikihow(how, max)
                assert len(how_1) == 1
                how_1[0].print()
                speak(how_1[0].summary)
                
                
                      
                
                                        
startExecution = mainthread()

class ui(QMainWindow):
    
    def __init__(self):
        super().__init__()
        self.ui = Ui_JARVISGUI()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.startTask)
        self.ui.pushButton_2.clicked.connect(self.close)
        
        
    def startTask(self):
        self.ui.movie = QtGui.QMovie("D:\\download\\960x0.gif")
        self.ui.label.setMovie(self.ui.movie)
        self.ui.movie.start()
        self.ui.movie = QtGui.QMovie("E:\\gifs for jarvis\\T8bahf.gif")
        self.ui.label_2.setMovie(self.ui.movie)
        self.ui.movie.start()
        self.ui.movie = QtGui.QMovie("D:\\download\\l.gif")
        self.ui.label_3.setMovie(self.ui.movie)
        self.ui.movie.start()
        self.ui.movie = QtGui.QMovie("D:\\download\\jaa.jpg")
        self.ui.label_5.setMovie(self.ui.movie)
        self.ui.movie.start()
        
        timer = QTimer(self)
        timer.timeout.connect(self.showtime)
        timer.start(1000)
        startExecution.start()
        
    
    
    def showtime(self):
        current_time = QTime.currentTime()
        current_date = QDate.currentDate()
        label_time= current_time.toString('hh:mm:ss')
        label_date = current_date.toString(Qt.ISODate)
        self.ui.textBrowser.setText(label_date)
        self.ui.textBrowser_2.setText(label_time)      
   
app = QApplication(sys.argv)
myjarvis = ui()
myjarvis.show()
exit(app.exec_())
sys.exit()
        

            
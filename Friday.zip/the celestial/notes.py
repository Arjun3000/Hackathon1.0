from datetime import datetime
from fileinput import filename
from fnmatch import translate
from importlib.resources import path
from time import sleep, time
from unittest import expectedFailure
from winsound import PlaySound
from googletrans import Translator
from gtts import gTTS
import googletrans
import pyttsx3
from playsound import playsound
import speech_recognition as sr
import os 
import time

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice',voices[0].id)
def speak(audio):
    engine.say(audio)
    engine.runAndWait()
    
      
def takecommand(): 
    r = sr.Recognizer()
    with sr.Microphone()as so:
        print("Listening.....")
        r.pause_threshold = 1
        audio = r.listen(so)
                
    try:
        print("Wait for few moments...")
        que = r.recognize_google(audio,language='en-in')
        print(f"YOU SAID : {que}")
    except Exception as w:
        print("SAY IT AGAIN PLEASE....")
        return "none"
    return que
        

        
def Notepad():
    speak("Tell Me a Query")
    speak("i am ready to write ")
    
    writes = takecommand()
    time = datetime.now().strftime("%H:%M")
    
    filename = str(time).replace(":","-")+"-note.txt"
    
    with open(filename,"w") as file:
        file.write(writes)
        
    path_1 = "C:\\Users\\91987\\Desktop\\the celestial\\"+ str(filename)
    
    path_2 = "C:\\Users\\91987\\Desktop\\database\\Notepad\\"+str(filename)
    
    os.rename(path_1,path_2)
    os.startfile(path_2)
    
    

        
    